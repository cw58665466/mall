window.host = '';
window.entId = '';
